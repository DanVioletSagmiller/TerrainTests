using System;
using UnityEngine;

[ExecuteAlways]
public class TerrainTool : MonoBehaviour
{
    public TerrainData TerrainData;

    [Range(0.0001f, 0.05f)]
    public float PerlinStretch;

    [Range(0f, 1f)]
    public float HeightMultiplier;

    public AnimationCurve PerlinSlope;

    private int HeightRes;
    private float[,] Mesh;

    public void OnEnable()
    {
        PullTerrain();
    }

    public void PullTerrain()
    {
        HeightRes = TerrainData.heightmapResolution;
        Mesh = TerrainData.GetHeights(
            0,
            0,
            HeightRes,
            HeightRes);
    }

    public void OnValidate()
    {
        RedrawTerrainMesh();
        UpdateHeightMap();
    }

    private void RedrawTerrainMesh()
    {
        for(int x = 0; x < HeightRes; x++)
        {
            for(int y = 0; y < HeightRes; y++)
            {
                Mesh[x, y]
                    = PerlinSlope.Evaluate(
                        Mathf.PerlinNoise(
                            (float)x * PerlinStretch,
                            (float)y * PerlinStretch)) 
                    * HeightMultiplier;
            }
        }
    }

    public void UpdateHeightMap()
    {
        TerrainData.SetHeights(0, 0, Mesh);
    }
}
